#ifndef __MACH__
#include "glad/glad.h"
#endif
#define GLFW_DLL
#define GLFW_INCLUDE_GLCOREARB
#include <GLFW/glfw3.h>
