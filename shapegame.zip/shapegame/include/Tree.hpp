#pragma once

namespace shapegame {
	class TreeNode {
	};
	
} // shapegame
